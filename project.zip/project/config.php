<?php

$conn = mysqli_connect('localhost','root','sunilyadav999VNS@','connectt');

?>